
from django.urls import path
from .views import *
from .models import *

urlpatterns = [

   path('home/', homepage , name='home'),
   path('register/', registerPage , name='register'),
   path('login', loginPage , name='login'),
   path('logout', logout_page , name='logout'),
   path('',  base_page, name='launch'),



   path('tasklist/', taskList , name='tasklist'),
   path('delete/ <int:id>/', delete_task , name='delete'),
   path('addlist', addList , name='addList'),


   path('items', item_page , name='items'),
   path('profile/', profilePage, name='profile'),
   
   path('uploadItem/', upload_item, name='uploadItem'),
   path('item/<int:id>/', item_details, name='item_details'),
   path('delete-item/<int:id>/', delete_item, name='delete_item'),
   path('edit-item/<int:id>/', edit_item, name='edit_item'),
]
