from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.

class UserAuthInfo(AbstractUser):
    image = models.ImageField(upload_to='media' )

    def __str__(self):
        return f'user:{self.username}'    
    
class TaskInfoModel(models.Model):
    title = models.CharField(max_length=50, null=True)
    discription = models.TextField()
    info_status = [
        ('pending','Pending'),
        ('inprogress','Inprogress'),
        ('completed','Completed'),
    ]
    status = models.CharField(choices=info_status, max_length=100 , null=True)
    type = models.CharField(max_length=50)
    deadline = models.DateField(default='',)
    def __str__(self):
        return f'Title: {self.title} - Status: {self.status}'



class ItemInfoModel(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    contact = models.CharField(max_length=50, null=True,blank=True)
    found_by = models.CharField(max_length=100)

    # image upload field
    image = models.ImageField(upload_to='items/')

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title