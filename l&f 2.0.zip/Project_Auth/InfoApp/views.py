from django.shortcuts import render,redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from .models import *


# Create your views here.
@login_required
def homepage(req):
    return render (req, 'home.html')



def registerPage(req):
    if req.method == "POST":
        username = req.POST.get('username')
        email = req.POST.get('email')
        confirm_password = req.POST.get('confirm_password')
        password = req.POST.get('password')
        image = req.FILES.get('image')

        if password == confirm_password:
            UserAuthInfo.objects.create_user(
                username=username,
                email=email,
                image=image,
                password=password,
            )
            return redirect('login')

    return render(req, 'register.html')

def loginPage(req):

    if req.method == "POST":
        
        username = req.POST.get('username')
        password = req.POST.get('password')
        user = authenticate(req, username=username, password=password)
        if user:
            login (req,user) 
            return redirect('home')
        else:
            return redirect ('login')
          
    return render (req, 'login.html')

@login_required
def taskList(req):

    context = {
        'data':TaskInfoModel.objects.all()
    }
    return render (req, 'list.html', context)

def delete_task(req, id):
    TaskInfoModel.objects.get(id=id).delete()
    return redirect ('tasklist')

@login_required
def upload_item(req):
    if req.method == "POST":
        title = req.POST.get('title')
        description = req.POST.get('description')
        contact = req.POST.get('contact')
        image = req.FILES.get('image')

        ItemInfoModel.objects.create(
            title=title,
            description=description,
            contact=contact,
            found_by=req.user.username,
            image=image
        )

        return redirect('items')

    return render(req, 'uploadItem.html')

@login_required
def logout_page(req):
    logout(req)
    return redirect('launch')

def addList(req):
    if req.method == "POST":
        title = req.POST.get('title')
        description = req.POST.get('description')
        status = req.POST.get('status')
        type = req.POST.get('type')
        deadline = req.POST.get('deadline')
        task = TaskInfoModel(
            title=title,
            discription=description,
            status=status,
            type=type,
            deadline=deadline
        )
        task.save()
        return redirect('tasklist') 
    return render (req, 'addList.html',)

@login_required
def item_page(req,):
    items = ItemInfoModel.objects.all()
    
    return render (req, 'items.html',{'items': items})

#delete items
@login_required
def delete_item(req, id):
    item = ItemInfoModel.objects.get(id=id)

    if item.found_by == req.user.username:   
        item.delete()

    return redirect('items')

#edit items
@login_required
def edit_item(req, id):
    item = ItemInfoModel.objects.get(id=id)

    if item.found_by != req.user.username:
        return redirect('items')   # ❌ block others

    if req.method == "POST":
        item.title = req.POST.get('title')
        item.description = req.POST.get('description')
        item.contact = req.POST.get('contact')

        if req.FILES.get('image'):
            item.image = req.FILES.get('image')

        item.save()
        return redirect('items')

    return render(req, 'edit_item.html', {'item': item})


@login_required
def profilePage(req):
    user = req.user   # logged-in user

    return render(req, 'profile.html', {'user': user})

def item_details(request, id):
    item = ItemInfoModel.objects.get(id=id)
    return render(request, 'item_details.html', {'item': item})

def base_page(req):
    return render (req, 'launch.html')