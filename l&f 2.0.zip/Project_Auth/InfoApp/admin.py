from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(UserAuthInfo),
admin.site.register(TaskInfoModel),
admin.site.register(ItemInfoModel),